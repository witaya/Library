
package librarydemo;

interface Calculate {
    
    public void cal();
 
}
