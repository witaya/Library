
package librarydemo;

interface Store {
    public void listbook();
}
