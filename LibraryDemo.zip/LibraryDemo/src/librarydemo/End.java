
package librarydemo;


public class End extends Message{
    public String x;
    
    End(){
    x="End Program\n";
    System.out.print(x);
    }
    
    End(String y){
    this();
    x=y;
    System.out.println(x);
    
    }
    
}
