
package librarydemo;

interface Select {
    
    public void select();
    
    
}
