
package librarydemo;


abstract class Library {
    

    public String bname;
    public String isbn;
    public String author;
    public String price;
    
    
    public String name;
    public String age;
    public String tel;
    public String address;
    public String userid;
    
    public int dis = 10;
    
    public String datebor;
    public int vip;
    
  
    
    abstract void addbook();
    abstract void addmember();
    abstract void listmem();
    
 
    
    
}
