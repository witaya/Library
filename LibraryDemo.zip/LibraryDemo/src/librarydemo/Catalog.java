
package librarydemo;


public abstract class Catalog implements Calculate {
    private int cartoon;
    private int scient;
    private int math;
    private int it;
    
    public void cal(){
    cartoon = 120;
    scient = 100;
    math = 100;
    it = 140;
    
    }
    
    

}
