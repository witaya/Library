
package librarydemo;

public class Message {
    
    Message(){
    
    System.out.print("");
    
    }
    
    Message(String m){
    
    System.out.print(m);
    }

}
