
package librarydemo;
import java.util.Scanner;

public class Return extends Library {
 Scanner reb = new Scanner(System.in);
    
 public  void addbook(){}
 public void select(){}
 public void listmem(){}
 public  void addmember(){}
 public void listbook(){}
 
 private String userid;
 private String bname;
 private String date;
 private int dis;
 private int datebor;
 
 private int total =0;
 
 String  c = "cartoon";
 String  sc = "scient";
 String m = "math";
 String  it = "it"; 
 
 public void rebook(){
     
 System.out.println("**************************");
 System.out.println("Enter member ID: ");
 userid = reb.nextLine();
 
 System.out.println("Enter book name: ");
 bname = reb.nextLine();
 System.out.println("Enter day of borrow:");
 datebor = reb.nextInt();
 System.out.println("Enter date of borrow:");
 date = reb.nextLine();

 
 if(datebor<=7){
 total += 0;
 
 }else{
 total += 5;
 }
  System.out.print("Total Price: "+total+"\n");
 }   
    
}
