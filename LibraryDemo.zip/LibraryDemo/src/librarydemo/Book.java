
package librarydemo;
import java.util.Scanner;
import java.util.*;
import java.util.ArrayList;

 class Book extends Library implements Select,Store{
    Scanner add = new Scanner(System.in);
    Scanner add2 = new Scanner(System.in);
    Scanner se = new Scanner(System.in);

    ArrayList<String> book = new ArrayList<String>();
    
    private int total =0;
    

    
    public void Book(){
        
    this.bname = bname;
    this.isbn = isbn;
    this.author = author;
    this.price = price;
    
    }
    
    public void listmem(){}
    
    public void addmember(){

    
    }
    
    
    public void listbook(){
    
    book.add("\nBook name:"+bname
            +"\nBook ISBN:"+isbn
            +"\nAuthor:"+author
            +"\nPrice:"+price);
    
    for (String temp : book)
    {
            System.out.println(temp);  
    }
    
    
    }
    
    public void addbook(){
    System.out.println("Enter Book name: ");
    bname = add.nextLine();
    System.out.println("Enter ISBN");
    isbn = add.nextLine();
    System.out.println("Enter author: ");
    author = add2.nextLine();
    System.out.println("Enter Price: ");
    price = add.nextLine();

    }
    private int cartoon;
    private int scient;
    private int math;
    private int it;
    private int vip;
    private int dis=0;
    private int net=0;
    int select;
    int i;
    
    public void select(){
    System.out.println("*****************************");
    System.out.println("Enter 99 Member");
    System.out.println("Enter 1 Cartoon 40.");
    System.out.println("Enter 2 Scient 50.");
    System.out.println("Enter 3 Math 50.");
    System.out.println("Enter 4 IT 60.");
    System.out.println("Enter 0 Fished");
    
    do{
    select = se.nextInt();
    i++;

    
    if(select==1){
    total += 40;
   // total = total;
    
    }else if(select ==2){
    total += 50;
  //  total = total;
    
    }else if(select==3){
    total +=50;
  //  total =total;
    
    }else if(select==4){
    total += 60;
  //  total = total;
    
    }else if(select==99){
    dis = total*10/100;
    net = total-dis;
    
    
    }
        }while(select!=0);
    
    System.out.print("Total Price: "+total+"\n");
    System.out.print("Total Price Member: "+net+"\n");
    
    }
    
    
//    int x;
//    
//    public int cal(int cartoon,int scient,int math,int it){
//        
//    x = cartoon+10;
//    total = x;    
//    System.out.println("Total Price: "+total);   
//
//    return total;
//    }
    
    
}
