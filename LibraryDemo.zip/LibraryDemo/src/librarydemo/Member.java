
package librarydemo;
import java.util.ArrayList;
import java.util.Scanner;

class Member extends Library {
    Scanner mem = new Scanner(System.in);

ArrayList<String> member = new ArrayList<String>();
    
    public void Member(){
    this.name = name;
    this.age = age;
    this.tel = tel;
    this.address = address;
    this.userid = userid;
    
    }
    public void addbook(){
    
  
   }
    
    public void listbook(){}
    
    public void listmem(){
    
    member.add("\nMember ID:"+
            userid+"\nName:"+name+"\nAge:"
            +age+"\nPhone:"+tel+"\nAddress:"
            +address);
    
    for (String temp : member)
    {
            System.out.println(temp);  
    }
    
    
    
    
    }
    public void addmember(){
        
  System.out.println("Enter Memeber ID: ");
    userid = mem.nextLine();
    System.out.println("Enter Member name: ");
    name = mem.nextLine();
    System.out.println("Enter Age:");
    age = mem.nextLine();
    System.out.println("Enter Phone: ");
    tel = mem.nextLine();
    System.out.println("Enter Address: ");
    address = mem.nextLine();
    

//idmember.add("L002"+"\tTest 2");
//idmember.add("L003"+"\ttest 3");
//idmember.add("L004"+"\ttest 4");

//idmember.add("L001"+"Witaya");
//idmember.add("L002"+"Test 2");
//idmember.add("L003"+"test 3");
//idmember.add("L004"+"test 4");
    

//for (String temp : member)
//    {
//            System.out.println("Member name:"+temp);  
//    }
    }
    public void select(){}
    
}
