
package librarydemo;
import java.util.Scanner;

public class LibraryDemo {

//    static Boolean running = true; 
    
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
        String id ="admin";
        String pass = "admin";
        String idin;
        String passin;
        int j=0;
        int fi=0;

     int cartoon = 40;
     int scient = 50;
     int math = 50;
     int it = 60;
      
        
        Mess me = new Mess();

        System.out.print("\nEnter your ID: ");
        idin = in.nextLine();
        System.out.print("Enter your Password: ");
        passin = in.nextLine();

        
        if(id.equals(idin)&&pass.equals(passin)){
        
        
        Book b = new Book();
        
        Member m = new Member();     
        
        Return re = new Return();
        
        
        
        do{
            j++;
                        System.out.print("\n**********Menu***********");
			System.out.println("\nEnter 1 for add book to library"
                                        + "\nEnter 2 for add member to library"
                                        +"\nEnter 3 for Borrow Book"
                                        +"\nEnter 4 for Return Book"
                                        +"\nEnter 5 for List of Member"
                                        +"\nEnter 6 for List of Book"
                                        +"\nEnter 0 for Exit");

			int answer = in.nextInt();
			switch (answer) {
			case 1:
				b.addbook();
				break;
			case 2:
				m.addmember();
				break;
                        case 3: b.select();
                                break;
                        case 4: re.rebook();
                                break;
                        case 5: m.listmem();
                                break;
                        case 6: b.listbook();
                                break;        
			}
                        
                         End end = new End();
		}while(fi==0);
		

        }else{
        System.out.println("Enter valid ID or Password!!");
        }
        
       
        
        
    }

    
}
