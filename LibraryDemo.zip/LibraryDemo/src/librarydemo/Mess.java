
package librarydemo;


public class Mess extends Message{
    
    Mess(){
    
    super("Webcome to Libery");

    }

    
    
}
